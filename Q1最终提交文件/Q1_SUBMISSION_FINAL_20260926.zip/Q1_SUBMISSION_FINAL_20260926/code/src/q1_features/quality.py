from __future__ import annotations

import csv
from pathlib import Path
from typing import Any, Iterable


def word_error_counts(reference: str, hypothesis: str) -> tuple[int, int, int, float]:
    ref = reference.split()
    hyp = hypothesis.split()
    # DP cells store (cost, S, D, I); deterministic tie order prefers
    # substitution, deletion, insertion.
    dp: list[list[tuple[int, int, int, int]]] = [[(0, 0, 0, 0) for _ in range(len(hyp) + 1)] for _ in range(len(ref) + 1)]
    for i in range(1, len(ref) + 1):
        dp[i][0] = (i, 0, i, 0)
    for j in range(1, len(hyp) + 1):
        dp[0][j] = (j, 0, 0, j)
    for i in range(1, len(ref) + 1):
        for j in range(1, len(hyp) + 1):
            if ref[i - 1] == hyp[j - 1]:
                dp[i][j] = dp[i - 1][j - 1]
                continue
            sub = dp[i - 1][j - 1]
            delete = dp[i - 1][j]
            insert = dp[i][j - 1]
            choices = [
                (sub[0] + 1, sub[1] + 1, sub[2], sub[3]),
                (delete[0] + 1, delete[1], delete[2] + 1, delete[3]),
                (insert[0] + 1, insert[1], insert[2], insert[3] + 1),
            ]
            dp[i][j] = min(choices, key=lambda x: (x[0], -x[1], -x[2], -x[3]))
    _, substitutions, deletions, insertions = dp[-1][-1]
    wer = (substitutions + deletions + insertions) / max(1, len(ref))
    return substitutions, deletions, insertions, wer


def load_reviews(path: str | Path, sample_id: str | None = None) -> list[dict[str, str]]:
    target = Path(path)
    if not target.is_file():
        return []
    with target.open(encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    return rows if sample_id is None else [r for r in rows if r.get("sample_id") == sample_id]



def vision_no_face_issue(
    diagnostic: dict[str, Any], rows: Iterable[dict[str, Any]],
) -> dict[str, Any] | None:
    """Return an explicit pairing issue for a successful zero-face result.

    OpenFace can exit successfully without producing any usable face candidate.
    That is a natural missing modality, not an extraction failure, but it must
    still prevent a later text-only review from releasing three-modal pairing.
    """
    vision_rows = list(rows)
    if not vision_rows or int(diagnostic.get("successful_candidate_count", 0) or 0) != 0:
        return None
    if not all(
        not bool(row.get("eligible")) and "no_face" in set(row.get("reasons", []))
        for row in vision_rows
    ):
        return None
    start = min(float(row.get("start", 0.0)) for row in vision_rows)
    end = max(float(row.get("end", start)) for row in vision_rows)
    return {
        "issue_type": "vision_no_face",
        "start": start,
        "end": end,
        "evidence": (
            "OpenFace completed with zero successful face candidates; "
            f"all {len(vision_rows)} selected frame rows are ineligible with reason=no_face"
        ),
    }

def audit_pairing(
    *, diagnostic_wer: float | None, aligned_word_fraction: float | None,
    automatic_issues: Iterable[dict[str, Any]], reviews: Iterable[dict[str, str]],
    wer_warn: float = 0.65, aligned_fraction_warn: float = 0.80,
) -> dict[str, Any]:
    issues = list(automatic_issues)
    triggered = bool(issues)
    text_alignment_triggered = False
    if diagnostic_wer is not None and diagnostic_wer > wer_warn:
        triggered = True
        text_alignment_triggered = True
        issues.append({"issue_type": "suspected_text_audio_mismatch", "evidence": f"diagnostic_wer={diagnostic_wer:.6f}"})
    if aligned_word_fraction is not None and aligned_word_fraction < aligned_fraction_warn:
        triggered = True
        text_alignment_triggered = True
        issues.append({"issue_type": "low_aligned_word_fraction", "evidence": f"aligned_word_fraction={aligned_word_fraction:.6f}"})
    review_rows = list(reviews)
    valid_pairs = {
        "confirmed_match": "release_pairing",
        "confirmed_mismatch": "quarantine_pairing",
        "unresolved": "keep_unresolved",
    }
    for row in review_rows:
        review_status = str(row.get("review_status", "")).strip()
        action = str(row.get("action", "")).strip()
        if review_status not in valid_pairs or action != valid_pairs[review_status]:
            raise ValueError(
                "invalid alignment review status/action pair: "
                f"review_status={review_status!r}, action={action!r}"
            )
        start = str(row.get("start", "")).strip()
        end = str(row.get("end", "")).strip()
        if bool(start) != bool(end):
            raise ValueError("alignment review start/end must both be blank or both be set")
        if start:
            try:
                start_value, end_value = float(start), float(end)
            except ValueError as exc:
                raise ValueError("alignment review start/end must be finite numbers") from exc
            if not (start_value < end_value):
                raise ValueError("alignment review interval must have end > start")

    automatic_issue_types = {
        str(issue.get("issue_type", "")).strip() for issue in issues
        if str(issue.get("issue_type", "")).strip()
    }
    for row in review_rows:
        if row.get("review_status") in {"confirmed_mismatch", "unresolved"}:
            issues.append({
                "issue_type": row.get("issue_type") or "manual_alignment_review",
                "start": row.get("start", ""), "end": row.get("end", ""),
                "evidence": row.get("evidence", ""),
                "review_status": row.get("review_status"), "action": row.get("action"),
            })
    mismatch = any(r.get("review_status") == "confirmed_mismatch" for r in review_rows)
    unresolved = any(r.get("review_status") == "unresolved" for r in review_rows)
    released_issue_types = {
        str(row.get("issue_type", "")).strip() for row in review_rows
        if row.get("review_status") == "confirmed_match"
    }
    all_automatic_issues_released = automatic_issue_types.issubset(released_issue_types)
    release = (
        bool(review_rows)
        and all(r.get("review_status") == "confirmed_match" for r in review_rows)
        and all_automatic_issues_released
    )
    if mismatch:
        status, paired = "confirmed_mismatch", False
    elif release:
        status, paired = "reviewed_match", True
    elif unresolved:
        status, paired = "unverifiable", False
    elif triggered:
        status, paired = "suspected", False
    else:
        status, paired = "no_issue_detected", True
    active_issues = [] if release else issues
    text_issue_rows = []
    for issue in active_issues:
        issue_type = str(issue.get("issue_type", "")).lower()
        if any(token in issue_type for token in ("text", "transcript", "word", "ctc", "alignment")):
            text_issue_rows.append(issue)
    if text_alignment_triggered and not release and not text_issue_rows:
        text_issue_rows = list(active_issues)
    quarantine_intervals: list[list[float]] = []
    all_local = bool(text_issue_rows)
    for issue in text_issue_rows:
        try:
            start, end = float(issue.get("start")), float(issue.get("end"))
            if not (end > start):
                raise ValueError
            quarantine_intervals.append([start, end])
        except (TypeError, ValueError):
            all_local = False
    if not text_issue_rows:
        text_time_policy = "accept"
    elif all_local:
        text_time_policy = "quarantine_intervals"
    else:
        text_time_policy = "quarantine_all"
        quarantine_intervals = []
    return {
        "pairing_status": status, "paired_use": paired, "issues": issues,
        "review_scope": review_rows, "text_time_policy": text_time_policy,
        "text_quarantine_intervals": quarantine_intervals,
        "released_issue_types": sorted(released_issue_types),
    }
